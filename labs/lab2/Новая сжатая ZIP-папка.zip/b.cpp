#include <iostream>
using namespace std;

struct Node {
	string data;
	Node *next;
	Node *prev;

	Node(string data)
	{
		this->data = data;
		this->next = nullptr;
		this->prev = nullptr;
	}
};

struct linked_list
{
	int size;
	Node *head;
	Node *tail;

	linked_list()
	{
		this->size = 0;
		this->head = nullptr;
		this->tail = nullptr;
	}

	void push_back(string data)
	{
		this->size++;
		Node *next = new Node(data);
		if (this->head == nullptr)
		{
			this->head = next;
			this->tail = next;
		}
		else
		{
			this->tail->next = next;
			this->tail = next;
		}
	}

    void prever(int m) {
		tail->next = head;
		for (int i = 0; i < m; i++) {
			head = head->next;
			tail = tail->next;
		}
		tail->next = nullptr;
    }

	void print() {
		Node *cur = this->head;
		while (cur != nullptr) {
			cout << cur->data << " ";
			cur = cur->next;
		}
		cout << endl;
	}
};

int main()
{
	linked_list *L = new linked_list();
    int n, m;
    cin >> n >> m;
    string s;
    for(int i = 0; i < n; i++){
        cin >> s;
        L->push_back(s);
    }
    L->prever(m);
    L->print();
	return 0;
}