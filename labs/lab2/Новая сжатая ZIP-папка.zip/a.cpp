#include <bits/stdc++.h>

using namespace std;

struct Node
{
	int data;
	Node *next;
	Node()
	{
		this->data = 0;
		this->next = NULL; 
	}
	Node(int data)
	{
		this->data = data;
		this->next = NULL;
	}
	Node(int data, Node *next)
	{
		this->data = data;
		this->next = next;
	}
};

struct linked_list
{
	int size;
	Node *head;
	Node *tail;

	linked_list()
	{
		this->size = 0;
		this->head = NULL;
		this->tail = NULL;
	}

	void push_back(int data)
	{
		this->size++;
		Node *nxt = new Node(data);
		if (this->head == NULL)
		{
			this->head = nxt;
			this->tail = nxt;
		}
		else
		{
			this->tail->next = nxt;
			this->tail = nxt;
		}
	}

    void check(int num){
        Node *cur = this->head;
        int pos = 0;
        int pos_1;
        int min = 2147483647;
        while(cur != NULL){
            int raz = abs(num - cur->data);
            if(raz < min){
				min = raz;
				pos_1 = pos;
            }
            pos++;
            cur = cur->next;
        }
        cout << pos_1;
    }
};
int main()
{
	linked_list *l = new linked_list();
    int n;
    cin >> n;
    int num;
    for(int i = 0; i < n; i++){
        cin >> num;
        l->push_back(num);
    }
    int m;
    cin >> m;
    l->check(m);
	return 0;
}