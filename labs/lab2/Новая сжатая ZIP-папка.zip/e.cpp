#include <iostream>
using namespace std;

struct Node
{
	string s;
	Node *next;

	Node()
	{
		this->s = s;
		this->next = nullptr;
	}

	Node(string s)
	{
		this->s = s;
		this->next = nullptr;
	}

	Node(string s, Node *next)
	{
		this->s = s;
		this->next = next;
	}
};

struct LinkedList
{
	int size;
	Node *head;
	Node *tail;

	LinkedList()
	{
		this->size = 0;
		this->head = nullptr;
		this->tail = nullptr;
	}
};
void push_back(Node **head, string s){
	Node *temp = new Node(s);
	temp->s = s;
	temp->next = (*head);
	(*head) = temp;
}
void check(Node *head){
    Node *cur = head;
    Node *nextt;
    if(!cur){
        return;
    }
    while(cur->next){
         if(cur->s == cur->next->s){
            nextt = cur->next->next;
            free(cur->next);
            cur->next = nextt;
        } else{
            cur= cur->next;
        }
    }
}
int counter(Node *head){
    int counter = 0;
    Node *cur = head;
    while(cur){
        counter++;
        cur = cur->next;
    }
    return counter;
}

void ouput(Node *cur){
	while(cur != NULL){
		cout << cur->s << "\n";
		cur = cur->next;
	}
}

int main(){
    int n;
    cin >> n;
    string s;
	Node *head = NULL;
    for(int i = 0; i < n; i++){
        cin >> s;
        push_back(&head, s);
    }
    check(head);
    cout<< "All in all: " << counter(head) << endl;;
    cout << "Students:" << endl;
    ouput(head);
	return 0;
}