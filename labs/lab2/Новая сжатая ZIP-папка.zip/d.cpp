#include <bits/stdc++.h>

using namespace std;

struct Node{
	int data;
    int cnt;
	Node *next;
	Node *prev;

	Node(int data){
		this->data = data;
		this->next = NULL;
		this->prev = NULL;
        this->cnt = 0;
	}
};

struct linked_list{
	int size;
    int max;
	Node *head;
	Node *tail;

	linked_list(){
		this->size = 0;
        this->max = 0;
		this->head = NULL;
		this->tail = NULL;
	}

	void push_back(int data){
		this->size++;
		Node *nxt = new Node(data);
		if (this->head == NULL){
			this->head = nxt;
			this->tail = nxt;
		}
		else{
            Node *cur = this->head;
			while(cur != NULL){
                if(cur->data == nxt->data){
                    cur->cnt++;
                    break;
                }
                if(cur->next == NULL){
                    cur->next = nxt;
                    break;
                }
                cur = cur->next;
            }
		}
    }
    void found(){
        Node *cur = this->head;
        while(cur != NULL){
            if(cur->cnt > max)
                max = cur->cnt;
            cur = cur->next;
        }
    }
    void output(){
        vector <int> vq;
        Node* cur = this->head;
        while(cur != NULL){
            if(cur->cnt == max){
                vq.push_back(cur->data);
            }
            cur = cur->next;
        }
        sort(vq.rbegin(), vq.rend());
        for(int i = 0; i < vq.size(); i++){
            cout << vq[i] << " ";
        }
    }
};
int main(){
    linked_list *l = new linked_list();
    int n;
    cin >> n;
    int num;
    for(int i = 0; i < n; i++){
        cin >> num;
        l->push_back(num);
    }
    l->found();
    l->output();
}