#include <iostream>
using namespace std;
struct Node{
    char data;
    Node *next;
    bool ballen_1;
    Node(char data){
        this->data = data;
        this->next = NULL;
    }
};
struct linked_list{
    Node *head;
    Node *tail;
    linked_list(){
        this->head = NULL;
        this->tail = NULL;
    }

    void push_back(char data){
        Node *nxt = new Node(data);
        if(!this->head){
            this->head = nxt;
            this->tail = nxt;
        }
        else{
            Node *cur = this->head;
            while(cur){
                if(cur->data == data){
                    cur->ballen_1 = true;
                    return;
                }
                cur = cur->next;
            }
            this->tail->next = nxt;
            this->tail = nxt;
        }
    }
    bool empty(){
        if(this->head != NULL)
            return false;
        return true;
    }
    
};
int main(){
    int n, m;
    char a;
    cin >> n;
    while(n--){
        linked_list *ll = new linked_list();
        cin >> m;
        while(m--){
            cin >> a;
            bool ballen = false;
            ll->push_back(a);
            Node *nxt = ll->head;
            while(nxt != NULL){
                if(nxt->ballen_1 == false){
                    cout << nxt->data << ' ';
                    ballen = true;
                    break;
                }
                nxt = nxt->next;
            }
            if(ballen == false)
                cout << "-1 ";
        }
        cout <<endl;
    }
}